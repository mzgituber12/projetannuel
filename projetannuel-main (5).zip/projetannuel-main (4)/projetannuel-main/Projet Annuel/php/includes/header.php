<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">



<header>
<nav class="navbar bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="logo_site.png" alt="" height="50">
        </a>
      <a class="navbar-brand" href="index.php">
        <i class="bi bi-house fs-2"></i>
      </a>
      <div id = "non_connecter"></div>
        <ul class="navbar-nav ms-auto d-flex flex-row align-items-center">
            <div id = "bouton_des_abonnement"></div>
            <li class="nav-item px-2">|</li>
            <div id = "bouton_planning"></div>
            <li class="nav-item px-2">|</li>
            <div id = "bouton_messagerie"></div>
            <li class="nav-item px-2">|</li>
            <li class="nav-item">
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
          </li>
        </ul>
    </div>
  </nav>
  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Paramètres</h5>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
        <div id = "mon_compte"></div>
        <div id = "autre_bouton"></div>
  <div id = "deconnexion_connecter_bouton"></div>
</ul>
</div>
</div>
</header>


<div id = "deconnexion_connecter"></div>




<script>
async function headerUser(token) {
    const base = (window.API_BASE || 'http://localhost:9000');
    const response = await fetch(base + "/enligne", {
        method: "GET",
        headers: {"Content-Type": "application/json", "Token": token},
    });
    const data = await response.json();
    
    if (data.message == "Pas identifié"){
    document.getElementById("non_connecter").innerHTML = `
        <ul class="navbar-nav ms-auto d-flex flex-row gap-2 align-items-center">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="connexion.php">S'identifier</a>
          </li>
        </ul> `;
    }
    
    if (data.message != "Pas identifié"){
        document.getElementById("bouton_planning").innerHTML = `
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="planning.php">Mon Planning</a>
          </li>`
        document.getElementById("bouton_messagerie").innerHTML = `
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="messagerie.php"><i class="bi bi-chat-dots"></i> Messagerie</a>
        </li>`


        document.getElementById("mon_compte").innerHTML = `
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="mon_profil.php">
        <i class="bi bi-person"></i> Mon Compte
        </a>
        </li>`

        document.getElementById("deconnexion_connecter_bouton").innerHTML = `
        <li class="nav-item">
        <a class="nav-link text-danger" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal"><i class="bi bi-box-arrow-right"></i> Se déconnecter</a>
        </li>`
        document.getElementById("deconnexion_connecter").innerHTML = `
            <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">Confirmer la déconnexion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    Êtes-vous sur de vouloir vous déconnecter ?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <a href="deconnexion.php" class="btn btn-danger">Oui, se déconnectez 👋👋</a>
                </div>
                </div>
            </div>
            </div>`;
        }

    if (data.role == "adherant"){
          document.getElementById("bouton_des_abonnement").innerHTML = `
          <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Nos Abonnements</a>
          </li>`
          
        document.getElementById("autre_bouton").innerHTML = `
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="demande_presta.php"><i class="bi bi-file-earmark-person"></i> Postuler</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="contrats.php"><i class="bi bi-pen"></i> Contrat</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="contrats.php"><i class="bi bi-lightbulb"></i>     Conseils</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="contrats.php"><i class="bi bi-book"></i> Catalogue</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="contrats.php"><i class="bi bi-clipboard"></i> Devis</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="contrats.php"><i class="bi bi-clock-history"></i> Rendez-Vous</a>
        </li>`
    }

    if (data.role == "prestataire"){
        document.getElementById("bouton_des_abonnement").innerHTML = `
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="abonnement.php">Nos Abonnements</a>
          </li>`
        document.getElementById("autre_bouton").innerHTML = `
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="suivi.php">Suivi des prestations</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="validations.php">Validations</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="calendrier.php">Calendrier</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="interventions.php">Interventions</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="contrats.php"><i class="bi bi-clock-history"></i> Rendez-Vous</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="factures.php"><i class="bi bi-receipt"></i> Factures</a>
        </li>`
    }

    if (data.role == "admin"){ 
        document.getElementById("autre_bouton").innerHTML = `
        <li class="nav-item">
             <a class="nav-link active" href="gestion_user.php"><i class="bi bi-people"></i> Gestion des Utilisateurs</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="gestion_evenement.php">Gestion des Evenements</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="gestion_service.php">Gestion des Services</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="gestion_intervention.php">Gestion des Interventions</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="gestion_catalogue.php">Gestion du Catalogue</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="gestion_conseils.php">Gestion des Conseils</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="gestion_notifs.php"><i class="bi bi-bell"></i> Gestion des Notifications</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="gestion_finance.php"><i class="bi bi-coin"></i><i class="bi bi-piggy-bank"></i> Gestion Financière</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="gestion_contact.php"><i class="bi bi-person-lines-fill"></i> Gestion des contacts</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="add_abonnement.php"><i class="bi bi-credit-card"></i> Creer des abonnements</a>
        </li>
        <li class="nav-item">
             <a class="nav-link active" href="abonnement_all.php"><i class="bi bi-credit-card"></i> Voir tout les abonnements</a>
        </li>`
    }
}


headerUser(localStorage.getItem('token'));
</script>


<header>
<nav><div id = "header">
</div></nav>
 </div>
</header>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>