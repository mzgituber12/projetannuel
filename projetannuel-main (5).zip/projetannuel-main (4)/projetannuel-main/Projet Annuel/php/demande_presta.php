<?php session_start();
include 'api_config.php';
include 'header/header.php'?>

<script src="online.js"></script>
<script src="admin.js"></script>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
</head>
<body>

<div class="d-flex justify-content-center">
    <div class="card p-4 shadow-sm w-100 mb-5 mt-5" style="max-width: 600px;">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <div class="mb-3">
                <label for="post" class="form-label">Choissir votre domaine :</label>
                <select class="form-select" name="post" id="post" onchange="champ_domaine()">
                    <option value="">Selectionner</option>
                    <option value="Transport">Transport</option>
                    <option value="Soin et bien-être">Soin et bien-être</option>
                    <option value="Tourisme / Hébergement">Tourisme / Hébergement</option>
                    <option value="Service à domicile">Service à domicile</option>
                    <option value="Loisirs & Sortie">Loisirs & Sortie</option>
                    <option value="Shoping">Shoping</option>
                </select>
            </div>

            <div class="mb-3 position-relative">
                <label for="Email" class="form-label">Email</label>
                <div class="d-flex">
                    <input type="email" class="form-control me-2" id="email">
                </div>
            </div>

            <div class="mb-3">
                <label for="Prénom" class="form-label">Prénom</label>
                <div class="d-flex">
                    <input type="text" class="form-control me-2" id="prenom" >
                </div>
            </div>

            <div class="mb-3">
                <label for="Nom" class="form-label">Nom</label>
                <div class="d-flex">
                    <input type="text" class="form-control me-2" id="nom" >
                </div>
            </div>

            <div class="mb-3">
                <label for="Age" class="form-label">Age</label>
                <div class="d-flex">
                    <input type="number" class="form-control me-2" id="age" >
                </div>
            </div>

            <div class="mb-3">
                <label for="Age" class="form-label">Télephone</label>
                <div class="d-flex">
                    <input type="number" class="form-control me-2" id="age" >
                </div>
            </div>

            <div class="mb-3">
                <label for="formFile" class="form-label">Pièce d'identité (recto)</label>
                <div class="d-flex">
                    <input class="form-control" type="file" id="formFile">
                </div>

            
            <div class="mb-3">
                <label for="formFile" class="form-label">Pièce d'identité (Verso)</label>
                <div class="d-flex">
                    <input class="form-control" type="file" id="formFile">
                </div>
            </div>

            <div class="mb-3">
                <label for="formFile" class="form-label">Diplome</label>
                <div class="d-flex">
                    <input class="form-control" type="file" id="formFile">
                </div>
            </div>

           <div id ="domain_champ"></div>

        <button type="button" class="btn btn-danger" onclick="">Postuler</button>

        </div>
    </div>
</div>
</div>
</div>


<?php include 'footer/footer.php'?>

<script>
function champ_domaine() {
    const select = document.getElementById("post");
    const valeur = select.value;

    const ajout_champ = document.getElementById("domain_champ");

    if (valeur === "Transport") {
        ajout_champ.innerHTML = `
            <div class="mb-3">
                <label class="form-label">Permis de conduire</label>
                <input class="form-control" type="file">
            </div>

            <div class="mb-3">
                <label class="form-label">Assurance véhicule</label>
                <input class="form-control" type="file">
            </div>
        `;
    }


    if(valeur == "Soin et bien-être"){
        ajout_champ.innerHTML = `
            <div class="mb-3">
                <label class="form-label">Diplôme / certification</label>
                <input class="form-control" type="file">
            </div>

            <div class="mb-3">
                <label class="form-label">Spécialité</label>
                <input class="form-control" type="text">
            </div>
        `;

    }



    if(valeur == "Service à domicile"){
        ajout_champ.innerHTML = `
            <div class="mb-3">
                <label class="form-label">Permis de conduire</label>
                <input class="form-control" type="file">
            </div>

            <div class="mb-3">
                <label class="form-label">Expérience</label>
                <input class="form-control" type="textarea">
            </div>
            
        `;

    }

    if(valeur == "Loisirs & Sortie"){
        ajout_champ.innerHTML = `
            <div class="mb-3">
                <label class="form-label">Type d’activité</label>
                <input class="form-control" type="text">
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <input class="form-control" type="textarea">
            </div>

            <div class="mb-3">
                <label class="form-label">Permis de conduire</label>
                <input class="form-control" type="file">
            </div>
        `;

    }

    if(valeur == "Shoping"){
        ajout_champ.innerHTML = `
            <div class="mb-3">
                <label class="form-label">Permis de conduire</label>
                <input class="form-control" type="file">
            </div>
        `;

    }

    if(valeur == "Tourisme / Hébergement"){
        ajout_champ.innerHTML = `

            <div class="mb-3">
                <label for="post" class="form-label">Choissir Type de logement :</label>
                <select class="form-select" name="posttt" id="posttt">
                    <option value="Chambres d'Hôtel">Chambres d'Hôtel</option>
                    <option value="Gîtes">Gîtes </option>
                    <option value="Camping">Camping</option>
                    <option value="Logements Insolites">Logements Insolites</option>

                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Adresse</label>
                <input class="form-control" type="text">
            </div>

            <div class="mb-3">
                <label class="form-label">Photos</label>
                <input class="form-control" type="file">
            </div>
        `;

    }
}
</script>