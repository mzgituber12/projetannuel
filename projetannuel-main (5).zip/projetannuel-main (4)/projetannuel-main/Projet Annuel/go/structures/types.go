package structures

type User struct {
	ID       int    `json:"id"`
	Nom      string `json:"nom"`
	Prenom   string `json:"prenom"`
	Age      int    `json:"age"`
	Email    string `json:"email"`
	Password string `json:"password"`
	Role     string `json:"role"`
	Langue   string `json:"langue"`
}

type Abonnement struct {
	Titre     string  `json:"titre"`
	Prix_mois float64 `json:"prix_mois"`
	Prix_an   float64 `json:"prix_an"`
	Contenue1 string  `json:"contenue1"`
	Contenue2 string  `json:"contenue2"`
	Contenue3 string  `json:"contenue3"`
	Contenue4 string  `json:"contenue4"`
}

type Result struct {
	Message  string `json:"message"`
	Value    int    `json:"value"`
	Role     string `json:"role"`
	Token    string `json:"token"`
	Tutoriel int    `json:"tutoriel"`
}

type Contrat struct {
	Nom string `json:"nom"`
}

type Conseil struct {
	ID      int    `json:"id"`
	Titre   string `json:"titre"`
	Contenu string `json:"contenu"`
	Image   string `json:"image"`
	Date    string `json:"date"`
}

type Evenement struct {
	ID          int     `json:"id"`
	Nom         string  `json:"nom"`
	Date        string  `json:"date"`
	Description string  `json:"description"`
	Tarif       float64 `json:"tarif"`
	Image       string  `json:"image"`
	Rejoindre   string  `json:"rejoindre"`
}

type Service struct {
	ID          int     `json:"id"`
	Nom         string  `json:"nom"`
	Description string  `json:"description"`
	Tarif       float64 `json:"tarif"`
	Image       string  `json:"image"`
	IdCategorie int     `json:"id_categorie"`
	Categorie   string  `json:"categorie"`
	Prestataire string  `json:"prestataire"`
	Rejoindre   string  `json:"rejoindre"`
}

type Categorie struct {
	ID  int    `json:"id"`
	Nom string `json:"nom"`
}

type Prestataire struct {
	ID        int    `json:"id"`
	Nom       string `json:"nom"`
	Prenom    string `json:"prenom"`
	Type      string `json:"type"`
	Telephone string `json:"telephone"`
}

type Intervention struct {
	ID            int     `json:"id"`
	IdService     int     `json:"id_service"`
	IdPrestataire int     `json:"id_prestataire"`
	IdUtilisateur int     `json:"id_utilisateur"`
	Date          string  `json:"date"`
	Statut        string  `json:"statut"`
	Montant       float64 `json:"montant"`
}

type Article struct {
	ID          int     `json:"id"`
	Titre       string  `json:"titre"`
	Image       string  `json:"image"`
	Description string  `json:"description"`
	Prix        float64 `json:"prix"`
}

type Contact struct {
	Contenu string `json:"contenu"`
	Email   string `json:"email"`
}

type Rdv struct {
	ID    int    `json:"id"`
	Title string `json:"title"`
	Start string `json:"start"`
	End   string `json:"end"`
}

type List struct {
	Contrat     []Contrat     `json:"contrat"`
	Conseil     []Conseil     `json:"conseil"`
	Evenement   []Evenement   `json:"evenement"`
	Service     []Service     `json:"service"`
	Categorie   []Categorie   `json:"categorie"`
	Prestataire []Prestataire `json:"prestataire"`
	Article     []Article     `json:"article"`
	Contact     []Contact     `json:"contact"`
	Utilisateur []User        `json:"utilisateur"`
}

type Etat struct {
	State string `json:"state"`
}
